
## How to pin repositories

* Navigate to your [GitHub Profile](https://github.com/USERNAME?tab=repositories)

* Click "Customize your pinned repositories"

* Click the "Repositories you contribute to" checkbox (this will allow you to "pin" Project 1 even if you aren't the "owner")

* Click the checkboxes for your project and 2-3 homework assignments that you would like to share

* Make sure each of these projects is deployed and add a link to the deployed project in their README files
